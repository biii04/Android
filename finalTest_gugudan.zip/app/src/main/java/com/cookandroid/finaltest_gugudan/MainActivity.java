package com.cookandroid.finaltest_gugudan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("구구단");

        EditText edtNum1 = findViewById(R.id.edtNum1);
        EditText edtNum2 = findViewById(R.id.edtNum2);
        EditText edtResult = findViewById(R.id.edtResult);

        Button btnNum = findViewById(R.id.btnNum1);
        Button btnResult = findViewById(R.id.btnResult);

        btnNum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int ran1 = new Random().nextInt(8)+2;
                int ran2 = new Random().nextInt(8)+2;

                edtNum1.setText(String.valueOf(ran1));
                edtNum2.setText(String.valueOf(ran2));
            }
        });

        ListView lv1 = findViewById(R.id.lv1);

        btnResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtNum1.getText().toString().equals("")||
                   edtNum2.getText().toString().equals("")||
                   edtResult.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, "값을 넣어주세요", Toast.LENGTH_SHORT).show();
                }else {
                    String str1 = edtNum1.getText().toString();
                    String str2 = edtNum2.getText().toString();
                    String str3 = edtResult.getText().toString();

                    int edt1 = Integer.parseInt(str1);
                    int edt2 = Integer.parseInt(str2);
                    int edt3 = Integer.parseInt(str3);

                    int edt4 = edt1*edt2;

                    if(edt3 == edt4){
                        Toast.makeText(MainActivity.this, "정답입니다", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "오답입니다", Toast.LENGTH_SHORT).show();
                        String[] values = new String[9];
                        for(int i=0; i<9; i++){
                            values[i] = String.valueOf(edt1) + "X" + (i+1) + "=" + (edt1*(i+1));

                            ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, values);
                            lv1.setAdapter(adapter);
                        }
                    }
                }

            }
        });
    }
}