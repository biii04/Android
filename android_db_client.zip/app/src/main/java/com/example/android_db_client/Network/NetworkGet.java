package com.example.android_db_client.Network;

import android.os.AsyncTask;
import android.util.Log;

import com.example.android_db_client.Custom_Adapter;
import com.example.android_db_client.UserInfo;

import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

// AsyncTask<>, 비동기, thread
// 비동기 모듈 안에서 네트워크 갖고옴
// 동기였다면 버튼 누르고 다른건 아무것도 못함(스크롤, 팝업 열기 등) 안드로이드는 무조건 비동기로 구현해야함(법적으로)
// Thread는 run()을 구현해야함
public class NetworkGet extends AsyncTask<String,Void,String> {

    private URL Url;
    private String URL_Adress = "http://10.100.102.49:9999/TestDB/testDB.jsp";  // 요청

    private Custom_Adapter adapter;

    public NetworkGet(Custom_Adapter adapter){
        this.adapter = adapter;
    }

    @Override
    protected void onPreExecute(){
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... strings) {  // ...은 배열로 들어옴
        String res = "";
        try{
            Url = new URL(URL_Adress);
            HttpURLConnection conn = (HttpURLConnection)Url.openConnection();

            //전송모드 설정
            conn.setDefaultUseCaches(false);
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");

            //content-type 설정
            conn.setRequestProperty("Content-type","application/x-www-form-urlencoded; charset=utf-8");
            //전송값 설정
            //string과 stringbuffer, stringbuilder의 차이--> 속도를 높이기 위해 string~애들 쓰고
            //자세한건 찾아보기(면접에서 잘 나옴)
            StringBuffer buffer = new StringBuffer();
            buffer.append("user_id").append("=").append(strings[0]);

            //서버로 전송
            OutputStreamWriter outStream = new OutputStreamWriter(conn.getOutputStream(),"utf-8");
            PrintWriter writer = new PrintWriter(outStream);
            writer.write(buffer.toString());
            writer.flush();

            StringBuilder builder = new StringBuilder();
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(),"utf-8"));
            String line;
            while((line = in.readLine()) != null){
                builder.append(line + "\n");
            }
            res = builder.toString();
        } catch (MalformedURLException e){
            e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
        }
        Log.i("Get result",res);
        return res;  //doinBackground가 끝나면 res가 나오는데 얘는 onPostExecute(String s)의 s로 감(후처리 작업)
        //json을 들고가서 파싱하고 userList(객체)로 만듦
    }

    @Override
    protected void onPostExecute(String s){
        super.onPostExecute(s);

        Log.i("get2",s);

        ArrayList<UserInfo> userList = new ArrayList<UserInfo>(); //데이터 받을곳
        int count = 0;
        try{
            count = JsonParser.getUserInfoJson(s,userList);
        } catch (JSONException e){
            e.printStackTrace();
        }
        if (count == 0){
        }
        else {
            adapter.setDatas(userList);
            adapter.notifyDataSetInvalidated();
        }
    }
}
