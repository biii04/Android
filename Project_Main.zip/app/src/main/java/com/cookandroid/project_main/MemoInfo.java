package com.cookandroid.project_main;

public class MemoInfo {
    String id, name, content, regdate;

    public MemoInfo(String id, String name, String content, String regdate) {
        this.id = id;
        this.name = name;
        this.content = content;
        this.regdate = regdate;
    }

}
