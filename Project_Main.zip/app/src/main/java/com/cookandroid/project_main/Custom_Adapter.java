package com.cookandroid.project_main;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class Custom_Adapter extends BaseAdapter {

    private Activity mAct;
    LayoutInflater mInflater;
    ArrayList<MemoInfo> mMemoInfoObjArr;  //객체 배열 만들어놓은거
    int mListLayout;
    private Custom_Adapter adapter;

    public Custom_Adapter(Activity a, int listLayout, ArrayList<MemoInfo> memoInfoObjArrayListT){
        mAct = a;
        mListLayout = listLayout;
        mMemoInfoObjArr = memoInfoObjArrayListT;
        mInflater = (LayoutInflater)a.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    public void setDatas(ArrayList<MemoInfo> arrayList){
        mMemoInfoObjArr = arrayList;
    }

    @Override
    public int getCount() {
        return mMemoInfoObjArr.size();
    }

    @Override
    public Object getItem(int i) {
        return mMemoInfoObjArr.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if(view==null)
            view= mInflater.inflate(mListLayout,viewGroup,false);
        final TextView tvID = view.findViewById(R.id.tv_id);

        final  TextView tvName = view.findViewById(R.id.tv_name);
        tvName.setText(mMemoInfoObjArr.get(i).name);

        final TextView tvContent = view.findViewById(R.id.tv_content);
        tvContent.setText(mMemoInfoObjArr.get(i).content);

        final TextView tvRegdate = view.findViewById(R.id.tv_regdate);
        tvRegdate.setText(mMemoInfoObjArr.get(i).regdate);
        return view;
    }
}
