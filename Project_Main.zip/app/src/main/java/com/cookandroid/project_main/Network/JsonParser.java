package com.cookandroid.project_main.Network;

import com.cookandroid.project_main.MemoInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class JsonParser {
    static public int getMemoInfoJson(String response, ArrayList<MemoInfo> memoList) throws JSONException{
        String ID;
        String Name;
        String Content;
        String Regdate;

        JSONObject rootJSON = new JSONObject(response);
        JSONArray jsonArray = new JSONArray(rootJSON.getString("datas"));  //json문법 오류


        for(int i=0; i<jsonArray.length();i++){
            JSONObject jsonObj = (JSONObject) jsonArray.get(i);
            if(jsonObj.getString("ID").toString().equals("null"))
                ID="-";
            else
                ID = jsonObj.getString("ID").toString();

            if(jsonObj.getString("NAME").toString().equals("null"))
                Name="-";
            else
                Name=jsonObj.getString("NAME").toString();

            if(jsonObj.getString("CONTENT").toString().equals("null"))
                Content="-";
            else
                Content=jsonObj.getString("CONTENT").toString();

            if(jsonObj.getString("REGDATE").toString().equals("null"))
                Regdate="-";
            else {
                Regdate = jsonObj.getString("REGDATE").toString();
                String temp[] = Regdate.split(" ");
                Regdate = temp[0] + "\n" + temp[1];
            }
            memoList.add(new MemoInfo(ID, Name, Content, Regdate));
        }
        return jsonArray.length();
    }
    static public int getResultJson(String response) throws JSONException{
        JSONArray jsonArray = new JSONArray(response);
        JSONObject jsonObject = new JSONObject(jsonArray.getString(0));
        return Integer.parseInt(jsonObject.getString("RESULT_OK"));
    }
}
